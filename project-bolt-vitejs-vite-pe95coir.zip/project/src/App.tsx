import { useState, useEffect, useRef } from 'react';
import * as faceapi from 'face-api.js';
import { motion, AnimatePresence } from 'framer-motion';
import './App.css';

function App() {
  const [mood, setMood] = useState<string>('');
  const [mealSuggestions, setMealSuggestions] = useState<string[]>([]);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const intervalRef = useRef<number>();

  useEffect(() => {
    const loadModels = async () => {
      try {
        setIsModelLoading(true);
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
          faceapi.nets.faceExpressionNet.loadFromUri('/models')
        ]);
        setIsModelLoading(false);
      } catch (error) {
        console.error('Error loading models:', error);
      }
    };
    loadModels();

    return () => stopSystem();
  }, []);

  const startSystem = async () => {
    if (videoRef.current && !isRunning) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: {} });
        videoRef.current.srcObject = stream;
        setIsRunning(true);
        startDetection();
      } catch (err) {
        console.error('Error accessing camera:', err);
      }
    }
  };

  const stopSystem = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = undefined;
    }
    
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    
    setIsRunning(false);
    setMood('');
    setMealSuggestions([]);
  };

  const startDetection = () => {
    intervalRef.current = window.setInterval(async () => {
      if (videoRef.current) {
        const detections = await faceapi
          .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceExpressions();

        if (detections) {
          const mood = Object.entries(detections.expressions)
            .reduce((a, b) => (a[1] > b[1] ? a : b))[0];
          setMood(mood);
          setMealSuggestions(getMealSuggestions(mood));
        }
      }
    }, 1000);
  };

  const getMealSuggestions = (mood: string) => {
    const suggestions: Record<string, string[]> = {
      happy: ['Ice Cream Sundae', 'Pizza', 'Burger'],
      sad: ['Chocolate Cake', 'Mac and Cheese', 'Chicken Soup'],
      angry: ['Spicy Ramen', 'Hot Wings', 'Curry'],
      neutral: ['Salad', 'Sandwich', 'Pasta']
    };
    return suggestions[mood.toLowerCase()] || suggestions.neutral;
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" }
    }
  };

  const buttonVariants = {
    hover: { scale: 1.05, transition: { duration: 0.2 } },
    tap: { scale: 0.95 },
    disabled: { opacity: 0.6 }
  };

  return (
    <div className="min-h-screen bg-slate-900 p-8">
      <motion.div 
        className="max-w-4xl mx-auto"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.h1 
          className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500 text-center mb-8"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          MoodMeal
        </motion.h1>
        
        <motion.div 
          className="glass-effect rounded-2xl shadow-2xl p-8"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col items-center">
            <AnimatePresence mode="wait">
              {isModelLoading ? (
                <motion.div 
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center p-4"
                >
                  <p className="text-lg text-indigo-200">Loading face detection models...</p>
                </motion.div>
              ) : (
                <motion.div
                  key="content"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full"
                >
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    className="rounded-xl shadow-2xl mb-6 w-full max-w-2xl mx-auto"
                  />
                  <div className="flex justify-center gap-6 mb-8">
                    <motion.button
                      variants={buttonVariants}
                      whileHover="hover"
                      whileTap="tap"
                      animate={isRunning ? "disabled" : ""}
                      onClick={startSystem}
                      disabled={isRunning}
                      className={`px-8 py-3 rounded-full font-semibold text-white shadow-lg transition-colors ${
                        isRunning 
                          ? 'bg-slate-600' 
                          : 'bg-gradient-to-r from-emerald-400 to-teal-500 hover:from-emerald-500 hover:to-teal-600'
                      }`}
                    >
                      Start Detection
                    </motion.button>
                    <motion.button
                      variants={buttonVariants}
                      whileHover="hover"
                      whileTap="tap"
                      animate={!isRunning ? "disabled" : ""}
                      onClick={stopSystem}
                      disabled={!isRunning}
                      className={`px-8 py-3 rounded-full font-semibold text-white shadow-lg transition-colors ${
                        !isRunning 
                          ? 'bg-slate-600' 
                          : 'bg-gradient-to-r from-rose-400 to-red-500 hover:from-rose-500 hover:to-red-600'
                      }`}
                    >
                      Stop Detection
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            <AnimatePresence>
              {mood && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="text-center"
                >
                  <motion.h2 
                    className="text-3xl font-bold mb-6 text-white"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    Current Mood: {' '}
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 capitalize">
                      {mood}
                    </span>
                  </motion.h2>
                  
                  <motion.div 
                    className="space-y-6"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <h3 className="text-2xl font-medium text-indigo-200">Recommended Meals</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {mealSuggestions.map((meal, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="meal-card bg-white/10 p-4 rounded-xl backdrop-blur-sm"
                        >
                          <p className="text-lg font-medium text-white">{meal}</p>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}

export default App;